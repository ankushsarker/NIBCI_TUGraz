load('artefacts.mat');
s = size(art);
l = s(1,2);
%calculate antorior and postorior
fc3 = art(63,:);
cp3 = art(77,:);
fcz = art(17,:);
cpz = art(27,:);
fc4 = art(99,:);
cp4 = art(113,:);
%calculate bipolar derivaion
bp1 = fc3 - cp3; %c3
bp2 = fcz - cpz; %cz
bp3 = fc4 - cp4; %c4
%calculate reference, dexter, and sinister 
c3 = art(70,:);
c5 = art(65,:);
c1 = art(21,:);
cz = art(22,:);
c2 = art(23,:);
c4 = art(106,:);
c6 = art(101,:);
%calculate laplace derivation
lp1 = c3 - ((c5 + c1 + fc3 + cp3)/4); %c3
lp2 = cz - ((c1 + c2 + fcz + cpz)/4); %cz
lp3 = c4 - ((c2 + c6 + fc4 + cp4)/4); %c4
%calcualte the average
aver = mean(art);
%calculate common average reference derivation
car1 = c3 - aver; %c3
car2 = cz - aver; %cz
car3 = c4 - aver; %c4
%plot
x = linspace(0,l/500,l);
minx = min(x);
maxx = max(x);
lc3 = min(c3); lcz = min(cz); lc4 = min(c4);
hc3 = max(c3); hcz = max(cz); hc4 = max(c4);
miny = min([lc3, lcz, lc4]) - 15;
maxy = max([hc3, hcz, hc4]) + 15;

%comparison for c3 channel

figure
subplot(4,1,1);
plot(x,c3);
xlim([minx maxx]);
ylim([miny maxy]);
title('Raw EEG of C3 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,2);
plot(x,bp1);
xlim([minx maxx]);
ylim([miny maxy]);
title('Bipolar filtered EEG of C3 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,3);
plot(x,lp1);
xlim([minx maxx]);
ylim([miny maxy]);
title('Laplace filtered EEG of C3 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,4);
plot(x,car1);
xlim([minx maxx]);
ylim([miny maxy]);
title('CAR filtered EEG of C3 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

%comparison for cz channel

figure
subplot(4,1,1);
plot(x,cz);
xlim([minx maxx]);
ylim([miny maxy]);
title('Raw EEG of Cz Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,2);
plot(x,bp2);
xlim([minx maxx]);
ylim([miny maxy]);
title('Bipolar filtered EEG of Cz Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,3);
plot(x,lp2);
xlim([minx maxx]);
ylim([miny maxy]);
title('Laplace filtered EEG of Cz Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,4);
plot(x,car2);
xlim([minx maxx]);
ylim([miny maxy]);
title('CAR filtered EEG of Cz Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

%comparison for c4 channel

figure
subplot(4,1,1);
plot(x,c4);
xlim([minx maxx]);
ylim([miny maxy]);
title('Raw EEG of C4 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,2);
plot(x,bp3);
xlim([minx maxx]);
ylim([miny maxy]);
title('Bipolar filtered EEG of C4 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,3);
plot(x,lp3);
xlim([minx maxx]);
ylim([miny maxy]);
title('Laplace filtered EEG of C4 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(4,1,4);
plot(x,car3);
xlim([minx maxx]);
ylim([miny maxy]);
title('CAR filtered EEG of C4 Channel');
grid on;
xlabel('Time(s)');
ylabel('Amplitude(µV)');