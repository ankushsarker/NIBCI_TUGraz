%% Calculation
clc;
clear;
load('BI5_segments_HTS');

%sepertating the non-target and target trials
nt = zeros(1,1);
tr = zeros(1,1);
a = 1;
b = 1;
for i = 1:length(classlabels)
    if classlabels(i) == 1
        nt(a,1) = i;
        a = a +1;
    elseif classlabels(i) == 2
        tr(b,1) = i;
        b = b + 1;
    end
end
nts = zeros(length(ch_selection), length(t), length(nt));
ts = zeros(length(ch_selection), length(t), length(tr));
for j = 1:length(tr)
    ts(:,:,j) = segments(:,:,tr(j,1));
end
for k = 1:length(nt)
    nts(:,:,k) = segments(:,:,nt(k,1));
end

%computaion of EP by avaeraging the trials
mts = mean(ts,3);
mnts = mean(nts,3);

%% - Ploting

%plot the two modalities for each channel

%calcualting the limits
maxy = max((max(mts, [], 'all')), (max(mnts, [], 'all'))) + 1;
miny = min((min(mts, [], 'all')), (min(mnts, [], 'all'))) - 1;
%making pairs
p1 = [mts(1,:); mnts(1,:)];
p2 = [mts(2,:); mnts(2,:)];
p3 = [mts(3,:); mnts(3,:)];

figure
subplot(3,1,1)
plot(t,p1);
ylim([miny maxy]);
grid on;
legend('Target','Non-Target');
title('Target and Non-Target Evoked Potentials for Fz Channel');
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(3,1,2)
plot(t,p2);
ylim([miny maxy]);
grid on;
legend('Target','Non-Target');
title('Target and Non-Target Evoked Potentials for Cz Channel');
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(3,1,3)
plot(t,p3);
ylim([miny maxy]);
grid on;
legend('Target','Non-Target');
title('Target and Non-Target Evoked Potentials for Pz Channel');
xlabel('Time(s)');
ylabel('Amplitude(µV)');

%plotting the modalities seperately for all channels

%calculating the limits
My = max(mnts, [],'all') + 1;
my = min(mnts, [],'all') - 1;

figure
subplot(2,1,1);
plot(t,mnts);
ylim([my My]);
grid on;
legend('Fz', 'Cz','Pz');
title('Non-Target Evoked Potentials for all Channels');
xlabel('Time(s)');
ylabel('Amplitude(µV)');

subplot(2,1,2);
plot(t,mts);
ylim([miny maxy]);
grid on;
legend('Fz', 'Cz','Pz');
title('Target Evoked Potentials for all Channels');
xlabel('Time(s)');
ylabel('Amplitude(µV)');